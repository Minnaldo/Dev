import java.util.Arrays;

public class MergeSort {

    static int[] tmp;

    public static void merge(int[] arr, int start, int mid, int end) {
        int left = start;
        int idx = start;
        int right = mid + 1;

        while (left <= mid && right <= end) {
            // 등호를 넣어주는 이유는?? ==> 같을때도 정렬을 해주어야 하기 때문에
            if (arr[left] <= arr[right]) {
                tmp[idx++] = arr[left++];
            } else {
                tmp[idx++] = arr[right++];
            }
        }

        if (right > end) {
            for (int i = left; i <= mid; i++) {
                tmp[idx++] = arr[i];
            }
        } else {
            for (int i = right; i <= end; i++) {
                tmp[idx++] = arr[i];
            }
        }

        for(int i = start; i<= end; i++){
            arr[i] = tmp[i];
        }
    }

    public static void divide(int[] arr, int start, int end) {
        if (start < end) {
            int mid = (start + end) / 2;
            divide(arr, start, mid);
            divide(arr, mid + 1, end);
            merge(arr, start, mid, end);
        }
    }

    public static void sort(int[] arr) {
        divide(arr, 0, arr.length - 1);
    }

    public static void main(String[] args) {
        int[] arr = {3, 4, 1, 8, 9, 10, 2, 7, 6, 5};

        tmp = new int[arr.length];

        System.out.println("==========정렬 전==========");
        System.out.println(Arrays.toString(arr));
        sort(arr);
        System.out.println("==========정렬 후==========");
        System.out.println(Arrays.toString(arr));
    }
}
