package ws;

public class BookManager {
	Book[] barr;
	int idx = 0;
	int max = 10;

	BookManager() {
		barr = new Book[10];
	}

	public void addBook(Book b) {
		if (idx > max) {
			// array doubling
			Book[] tmp = new Book[max * 2];
			System.arraycopy(barr, 0, tmp, 0, barr.length);
			barr = tmp;
			idx++;
			max *= 2;
		} else {
			barr[idx] = b;
			idx++;
		}
	}

	public void searchBook() {
		for (int i = 0; i < idx; i++) {
			System.out.println(barr[i].toString());
		}
	}

	public void serachIsbn(String isbn) {
		for (int i = 0; i < idx; i++) {
			if (barr[i].getIsbn().equals(isbn)) {
				System.out.println(barr[i].toString());
			}
		}
	}

	// TODO
	public void search(Book b) {
		for (int i = 0; i < idx; i++) {
			if (barr[i] instanceof Magazine) {
				// 매거진
			} else if (barr[i] instanceof Book) {
				// 책
			}
		}
	}

	public void searchPublisher(String publisher) {
		for (int i = 0; i < idx; i++) {
			if (barr[i].getPublisher().equals(publisher)) {
				System.out.println(barr[i].toString());
			}
		}
	}

	public void searchPrice(int price) {
		for (int i = 0; i < idx; i++) {
			if (barr[i].getPrice() < price) {
				System.out.println(barr[i].toString());
			}
		}
	}

	public int getPriceSum() {
		int sum = 0;
		for (int i = 0; i < idx; i++) {
			sum += barr[i].getPrice();
		}
		return sum;
	}

	public int getAverage() {
		int sum = 0;
		for (int i = 0; i < idx; i++) {
			sum += barr[i].getPrice();
		}

		return sum / idx;
	}
}
