package ws;

public class BookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
